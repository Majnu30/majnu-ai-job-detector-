import streamlit as st
import pickle

text_model = pickle.load(open("text_model.pkl", "rb"))
url_model = pickle.load(open("url_model.pkl", "rb"))
text_vectorizer = pickle.load(open("text_vectorizer.pkl", "rb"))
url_vectorizer = pickle.load(open("url_vectorizer.pkl", "rb"))

st.title("Fake Job Detection System")

st.write("Enter Job URL and Job Description")

user_url = st.text_input("Enter Job URL")
user_text = st.text_area("Paste Job Description")

if st.button("Predict"):

    url_vec = url_vectorizer.transform([user_url])
    text_vec = text_vectorizer.transform([user_text])

    url_pred = url_model.predict(url_vec)[0]
    text_pred = text_model.predict(text_vec)[0]

    if url_pred == 1 and text_pred == 1:
        result = "Fake Job ❌"
    elif url_pred == 0 and text_pred == 0:
        result = "Real Job ✅"
    else:
        result = "Suspicious ⚠"

    st.subheader("Prediction Result:")
    st.success(result)
